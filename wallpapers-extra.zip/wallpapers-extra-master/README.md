# Antergos Wallpapers (extra)
User contributed wallpapers

## CONTRIBUTORS
- Blinky [https://ello.co/kut-n-paste]
- Fedorai Zakaja
- Modisc
- Xose M. [http://xmgz.eu]
- Digoxinum
- Reo (Ola Westberg) [http://www.moonrock.net76.net/caferetro/cafe.html]
- Angel Stojanov [https://forum.antergos.com/user/stojanov]

## Images
![antergos-logo-blue-bright.png](antergos-logo-blue-bright.png)
![antergos-logo-blue-everyone.png](antergos-logo-blue-everyone.png)
![antergos-logo-blue.png](antergos-logo-blue.png)
![antergos-logo-blue-smoke.png](antergos-logo-blue-smoke.png)
![antergos-logo-code.png](antergos-logo-code.png)
![antergos-logo-mini-bw.png](antergos-logo-mini-bw.png)
![antergos-logo-stripes-blue.png](antergos-logo-stripes-blue.png)
![antergos-stripes.png](antergos-stripes.png)
![antergos-organ.jpg](antergos-organ.jpg)
![back-alley-graffiti.jpg](back-alley-graffiti.jpg)
![beach.jpg](beach.jpg)
![bee.jpg](bee.jpg)
![ebook-cover.jpg](ebook-cover.jpg)
![european-reminisce.jpg](european-reminisce.jpg)
![field.jpg](field.jpg)
![fire.jpg](fire.jpg)
![flower.jpg](flower.jpg)
![kaffee.jpg](kaffee.jpg)
![kaffee-picture.jpg](kaffee-picture.jpg)
![lago-verde.jpg](lago-verde.jpg)
![looking-up.jpg](looking-up.jpg)
![miracle-beach.jpg](miracle-beach.jpg)
![morning-mist.jpg](morning-mist.jpg)
![open-shell.jpg](open-shell.jpg)
![paws.jpg](paws.jpg)
![prairie-hay.jpg](prairie-hay.jpg)
![prairie-salt.jpg](prairie-salt.jpg)
![purple.jpg](purple.jpg)
![reflection.jpg](reflection.jpg)
![antergos-shadow.png](antergos-shadow.png)
![antergos-simple.jpg](antergos-simple.jpg)
![antergos-wood.jpg](antergos-wood.jpg)
